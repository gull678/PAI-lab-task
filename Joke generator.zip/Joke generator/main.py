import requests
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

JOKE_API_URL = "https://v2.jokeapi.dev/joke/Any"

@app.get("/joke")
def get_joke():
    try:
        response = requests.get(JOKE_API_URL)
        response.raise_for_status()  
        joke_data = response.json()

        if joke_data.get("type") == "single":
            joke = joke_data.get("joke", "No joke found!")
        else:
            joke = f"{joke_data.get('setup', 'No setup')} - {joke_data.get('delivery', 'No punchline')}"

        return {"joke": joke}
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Error fetching joke: {str(e)}")
